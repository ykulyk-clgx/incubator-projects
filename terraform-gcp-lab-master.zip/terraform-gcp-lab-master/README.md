Terraform HW, GCP inf
