<h1>Home assignment. GCP module.</h1>

<h3>Creation of standart envs., compute engine, templates, mig, lb, web software, storage, bigquery, logging, sheduler, pub/sub, cloud functions.</h3>

<h3>Task should be done via GCP Shell (gcloud, gsutil commands) and GCP Console (WEB GUI).</h3>

<h4>Task 1:</h4>

1)

2)

3)

4)

5)

6)

<h4>Task 2:</h4>


<h4>Task 3:</h4>
